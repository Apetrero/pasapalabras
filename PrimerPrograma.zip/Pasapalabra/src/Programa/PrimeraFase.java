package Programa;

import java.util.Scanner;

public class PrimeraFase {

	private static final Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO A pasapalabra
		String a;
		String e;
		String i;
		String o;
		String u;

		String respuesta_a = "Armageddon";
		String respuesta_e = "Ebullicion";
		String respuesta_i = "Infojobs";
		String respuesta_o = "Oblak";
		String respuesta_u = "Ukelele";
		int aciertos = 0;
		int fallos = 0;

		System.out.println("Bienvenido a Pasapalabra (fase beta). Empieza el juego. ¿Serás capáz de ganar?");

		System.out.print(
				"Con la A, nombre de la película del 1998 portagonizada por Bruce Willis donde un equipo de astronautas salvan la tierra de un meteorito: "); // Armageddon
		a = teclado.next();

		if (a.equals(respuesta_a)) {
			System.out.println("Respuesta Correcta");
			aciertos++;
		} else {
			System.out.println("Error");
			fallos++;
		}

		//

		System.out.print("Con la E, proceso físico en el que un líquido pasa a estado gaseoso: "); // Ebullición
		e = teclado.next();

		if (e.equals(respuesta_e)) {
			System.out.println("Respuesta Correcta");
			aciertos++;
		} else {
			System.out.println("Error");
			fallos++;
		}

		//

		System.out.print("Con la I, empresa que ayuda a las personas en la búsqueda de trabajo: "); // Infojobs
		i = teclado.next();

		if (i.equals(respuesta_i)) {
			System.out.println("Respuesta Correcta");
			aciertos++;
		} else {
			System.out.println("Error");
			fallos++;
		}

		//

		System.out.print("Con la O, apellido del portero esloveno del Atlético de Madrid: "); // Oblak
		o = teclado.next();

		if (o.equals(respuesta_o)) {
			System.out.println("Respuesta Correcta");
			aciertos++;
		} else {
			System.out.println("Error");
			fallos++;
		}

		//

		System.out.print(
				"Con la u, nombre del instrumento utilizado principalmente en la música de las islas Hawái, Tahití y Rapa Nui que originalmente tenía cinco cuerdas: "); // Ukelele
		u = teclado.next();

		if (u.equals(respuesta_u)) {
			System.out.println("Respuesta Correcta");
			aciertos++;
		} else {
			System.out.println("Error");
			fallos++;
		}

		//

		System.out.println("");

		//

		if (aciertos == 5) {
			System.out.println("¡Felicidadea! Has acertado todas las preguntas");
			System.out.println("Aciertos: " + aciertos);
			System.out.println("Fallos: " + fallos);
		} else {
			System.out.println("Aciertos: " + aciertos);
			System.out.println("Fallos: " + fallos);
		}

	}

}
